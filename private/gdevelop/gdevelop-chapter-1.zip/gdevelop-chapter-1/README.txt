GDevelop Essentials - Chapter 1 project
=======================================
1. Unzip this whole folder (right-click > Extract All). Keep lesson_1_game.json and the assets folder together.
2. Open the GDevelop desktop app.
3. Choose Open a project (File > Open), then pick lesson_1_game.json.
4. Follow the tasks on your lesson card. Save your work often (Ctrl+S).
You do not need a GDevelop account.
